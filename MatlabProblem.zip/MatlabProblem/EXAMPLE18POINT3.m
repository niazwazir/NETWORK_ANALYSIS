%Example-18.2
clc
close all
clear all
V = 10;
R = 75;
XL = 25;
XC = 60;
xtotal = (XL-XC) 
Z   = (sqrt(R^2+xtotal^2))
angle1 = atand(xtotal/R)
I = V/Z
I1 = (V/Z)*1000 %%%%%%%%%%%%%%%%%%%%%%%%%%Current in Milliampere
Iangle = (-angle1)
V_R = I1*R
V_L = I1*XL
V_C = I1*XC
