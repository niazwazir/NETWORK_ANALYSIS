clc
clear all
close all
R = 5.6;
L = 10*10^-3;
f = 100*10^3;
C = 470*10^-12;
xc = (1/(2*pi*f*C))/1000 %we divide 1000 becuase answer want in kilo ohm
xl = (2*pi*f*L)/1000
xtotal = (xl-xc) 
z = (sqrt(R^2+xtotal^2))
angle = atand(xtotal/R)
