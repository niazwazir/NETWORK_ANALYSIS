%Example-18.2
clc
close all
clear all
R = 3.3;
C = 0.02*10^-6;
L = 100*10^-3;
f1 = 1*10^3; %%%%%%%%%%%%%%%%%%%%%%%%% (a) AT FREQUECNY 1 kHZ
xc1 = (1/(2*pi*f1*C))/1000 %we divide 1000 becuase answer want in kilo ohm
xl1 = (2*pi*f1*L)/1000
xtotal1 = (xl1-xc1) 
z1   = (sqrt(R^2+xtotal1^2))
angle1 = atand(xtotal1/R)

f2 = 2*10^3; %%%%%%%%%%%%%%%%%%%%%%%%% (b) AT FREQUECNY 2 kHZ
xc2 = (1/(2*pi*f2*C))/1000 %we divide 1000 becuase answer want in kilo ohm
xl2 = (2*pi*f2*L)/1000
xtotal2 = (xl2-xc2) 
z2 = (sqrt(R^2+xtotal2^2))
angle2 = atand(xtotal2/R)


f3 = 3.5*10^3; %%%%%%%%%%%%%%%%%%%%%%%%% (c) AT FREQUECNY 3.5 kHZ
xc3 = (1/(2*pi*f3*C))/1000 %we divide 1000 becuase answer want in kilo ohm
xl3 = (2*pi*f3*L)/1000
xtotal3 = (xl3-xc3) 
z3 = (sqrt(R^2+xtotal3^2))
angle3 = atand(xtotal3/R)

f4 = 5*10^3; %%%%%%%%%%%%%%%%%%%%%%%%% (c) AT FREQUECNY 5 kHZ
xc4 = (1/(2*pi*f4*C))/1000 %we divide 1000 becuase answer want in kilo ohm
xl4 = (2*pi*f4*L)/1000
xtotal4 = (xl4-xc4) 
z4 = (sqrt(R^2+xtotal4^2))
angle4 = atand(xtotal4/R)